# simpleSB
Tutorial Install:
<br><a href="http://www.youtube.com/watch?feature=player_embedded&v=bKfk7ek91iU
" target="_blank"><img src="http://img.youtube.com/vi/bKfk7ek91iU/0.jpg" 
alt="Tutorial Install" width="240" height="180" border="10" /></a>

<a href="http://www.youtube.com/watch?feature=player_embedded&v=wNYsqSFsGxU
" target="_blank"><img src="http://img.youtube.com/vi/wNYsqSFsGxU/0.jpg" 
alt="Tutorial Install" width="240" height="180" border="10" /></a>

<hr><br>
Command : <br> 
me          = Mengirim Kontak Sendiri <br>
speed       = Test Kecepatan Bot <br>
spic <tag>  = Kirim Foto Profile yg di Tag <br>
scover <tag>= Kirim Foto Cover yg di Tag <br>
tagall      = Tag Semua Member dalam Group <br>
ceksider    = Mengecek CCTV <br>
offread     = Tampilkan CCTV <br>
<hr>
source : linepy by https://github.com/fadhiilrachman/
